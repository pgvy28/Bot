{
    "flimsy rod": {
        "Obtained From": "Khởi đầu",
        "Cost (C$)": 0,
        "Lure (%)": 0,
        "Luck (%)": 0,
        "Control": 0,
        "Resilience (%)": 10.4,
        "Max Kg": "-"
    },
    "fischer's rod": {
        "Obtained From": "Gói khởi đầu",
        "Cost (C$)": 0,
        "Lure (%)": 5,
        "Luck (%)": 5,
        "Control": 0.05,
        "Resilience (%)": 5,
        "Max Kg": 50
    },
    "training rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 300,
        "Lure (%)": 10,
        "Luck (%)": -70,
        "Control": 0.2,
        "Resilience (%)": 20,
        "Max Kg": 9
    },
    "plastic rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 900,
        "Lure (%)": 10,
        "Luck (%)": 15,
        "Control": 0,
        "Resilience (%)": 10,
        "Max Kg": 100
    },
    "carbon rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 2000,
        "Lure (%)": -10,
        "Luck (%)": 25,
        "Control": 0.05,
        "Resilience (%)": 10,
        "Max Kg": 600
    },
    "fast rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 4500,
        "Lure (%)": 45,
        "Luck (%)": -15,
        "Control": 0.05,
        "Resilience (%)": -12,
        "Max Kg": 175
    },
    "lucky rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 5250,
        "Lure (%)": -30,
        "Luck (%)": 60,
        "Control": 0.05,
        "Resilience (%)": -12,
        "Max Kg": 175
    },
    "long rod": {
        "Obtained From": "Moosewood",
        "Cost (C$)": 4500,
        "Lure (%)": 20,
        "Luck (%)": 30,
        "Control": -0.1,
        "Resilience (%)": 0,
        "Max Kg": 250
    },
    "stone rod": {
        "Obtained From": "Ancient Isle",
        "Cost (C$)": 3000,
        "Lure (%)": -25,
        "Luck (%)": 10,
        "Control": 0,
        "Resilience (%)": 5,
        "Max Kg": 900
    },
    "magma rod": {
        "Obtained From": "Roslit Bay (Nhiệm vụ Orc)",
        "Cost (C$)": "-",
        "Lure (%)": -70,
        "Luck (%)": 15,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 1200,
        "Ability": "Có khả năng câu cá trong núi lửa"
    },
    "fungal rod": {
        "Obtained From": "Mushgrove Swamp (Nhiệm vụ Agaric)",
        "Cost (C$)": "-",
        "Lure (%)": -10,
        "Luck (%)": 45,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 200,
        "Ability": "70% cơ hội nhận 45 giây hiệu ứng May mắn IV (+20% May mắn) sau khi câu"
    },
    "steady rod": {
        "Obtained From": "Roslit Bay",
        "Cost (C$)": 7000,
        "Lure (%)": -60,
        "Luck (%)": 35,
        "Control": 0.05,
        "Resilience (%)": 30,
        "Max Kg": 100000,
        "Ability": "Tăng kích thước nút rung lắc"
    },
    "fortune rod": {
        "Obtained From": "Roslit Bay",
        "Cost (C$)": 12750,
        "Lure (%)": -35,
        "Luck (%)": 110,
        "Control": 0,
        "Resilience (%)": -15,
        "Max Kg": 700
    },
    "rapid rod": {
        "Obtained From": "Roslit Bay",
        "Cost (C$)": 14000,
        "Lure (%)": 72,
        "Luck (%)": -20,
        "Control": 0,
        "Resilience (%)": -20,
        "Max Kg": 700
    },
    "magnet rod": {
        "Obtained From": "Terrapin Island",
        "Cost (C$)": 15000,
        "Lure (%)": -10,
        "Luck (%)": 0,
        "Control": 0.05,
        "Resilience (%)": 0,
        "Max Kg": 10000,
        "Ability": "Tăng cơ hội câu được Thùng hàng lên mức cực cao"
    },
    "nocturnal rod": {
        "Obtained From": "Vertigo",
        "Cost (C$)": 11000,
        "Lure (%)": -10,
        "Luck (%)": 70,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 2000,
        "Ability": "Có thể câu cá hoạt động ban ngày hoặc ban đêm vào bất kỳ thời điểm nào"
    },
    "reinforced rod": {
        "Obtained From": "Desolate Deep",
        "Cost (C$)": 20000,
        "Lure (%)": 0,
        "Luck (%)": 25,
        "Control": 0.05,
        "Resilience (%)": 0,
        "Max Kg": "∞",
        "Ability": "Cho phép câu cá trong Hồ nước mặn và Núi lửa"
    },
    "arctic rod": {
        "Obtained From": "Northern Summit",
        "Cost (C$)": 25000,
        "Lure (%)": 45,
        "Luck (%)": 65,
        "Control": 0.18,
        "Resilience (%)": 15,
        "Max Kg": 80000
    },
    "avalanche rod": {
        "Obtained From": "Overgrowth Caves",
        "Cost (C$)": 35000,
        "Lure (%)": 40,
        "Luck (%)": 68,
        "Control": 0.15,
        "Resilience (%)": 10,
        "Max Kg": 65000
    },
    "phoenix rod": {
        "Obtained From": "Ancient Isle",
        "Cost (C$)": 40000,
        "Lure (%)": 55,
        "Luck (%)": 35,
        "Control": 0.05,
        "Resilience (%)": -10,
        "Max Kg": 4000,
        "Ability": "40% cơ hội câu được Scorched Mutation (Giá trị ×1.3)"
    },
    "scurvy rod": {
        "Obtained From": "Forsaken Shores",
        "Cost (C$)": 50000,
        "Lure (%)": 15,
        "Luck (%)": 50,
        "Control": 0,
        "Resilience (%)": 15,
        "Max Kg": 2000
    },
    "midas rod": {
        "Obtained From": "Travelling Merchant",
        "Cost (C$)": 55000,
        "Lure (%)": 60,
        "Luck (%)": 10,
        "Control": 0,
        "Resilience (%)": -20,
        "Max Kg": 4000,
        "Ability": "60% cơ hội câu được Midas Mutation (Giá trị ×2)"
    },
    "crystalized rod": {
        "Obtained From": "Northern Summit (Diamond Puzzle)",
        "Cost (C$)": 35000,
        "Lure (%)": 35,
        "Luck (%)": 45,
        "Control": 0.15,
        "Resilience (%)": 15,
        "Max Kg": 25000,
        "Ability": "12% cơ hội câu được Crystalized Mutation (Giá trị ×1.75)"
    },
    "brick rod": {
        "Obtained From": "Minish's Quest",
        "Cost (C$)": 13337,
        "Lure (%)": 0,
        "Luck (%)": 75,
        "Control": 0.35,
        "Resilience (%)": 35,
        "Max Kg": "∞",
        "Ability": "Tất cả cá câu được có Studded Mutation (Giá trị ×1.1)"
    },
    "aurora rod": {
        "Obtained From": "Vertigo",
        "Cost (C$)": 90000,
        "Lure (%)": 10,
        "Luck (%)": 60,
        "Control": 0.06,
        "Resilience (%)": 6,
        "Max Kg": 6000,
        "Ability": "15% cơ hội câu được Aurora Mutation (Giá trị ×6.5), tăng lên 30% khi có Cực quang"
    },
    "mythical rod": {
        "Obtained From": "Travelling Merchant",
        "Cost (C$)": 110000,
        "Lure (%)": 0,
        "Luck (%)": 45,
        "Control": 0.05,
        "Resilience (%)": 0,
        "Max Kg": 2000,
        "Ability": "30% cơ hội câu được Mythical Mutation (Giá trị ×4.5)"
    },
    "kings rod": {
        "Obtained From": "Keepers Altar",
        "Cost (C$)": 120000,
        "Lure (%)": -45,
        "Luck (%)": 55,
        "Control": 0.15,
        "Resilience (%)": 35,
        "Max Kg": "∞",
        "Ability": "Tất cả cá câu được lớn hơn 15%"
    },
    "ice warpers rod": {
        "Obtained From": "Northern Summit (Lever Puzzle)",
        "Cost (C$)": 65000,
        "Lure (%)": 50,
        "Luck (%)": 60,
        "Control": 0.15,
        "Resilience (%)": 20,
        "Max Kg": 75000
    },
    "depthseeker rod": {
        "Obtained From": "Atlantis",
        "Cost (C$)": 40000,
        "Lure (%)": 55,
        "Luck (%)": 70,
        "Control": 0.17,
        "Resilience (%)": 25,
        "Max Kg": 50000
    },
    "champions rod": {
        "Obtained From": "Atlantis (Central Area)",
        "Cost (C$)": 80000,
        "Lure (%)": 45,
        "Luck (%)": 65,
        "Control": 0.25,
        "Resilience (%)": 30,
        "Max Kg": 200000
    },
    "trident rod": {
        "Obtained From": "Desolate Deep",
        "Cost (C$)": 150000,
        "Lure (%)": 20,
        "Luck (%)": 150,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 6000,
        "Ability": "Có cơ hội đâm cá trong lúc kéo (thêm tiến trình vào Thanh tiến trình); 30% cơ hội câu được Atlantean Mutation (Giá trị ×3)"
    },
    "summit rod": {
        "Obtained From": "Frigid Cavern",
        "Cost (C$)": 300000,
        "Lure (%)": 15,
        "Luck (%)": 75,
        "Control": 0.25,
        "Resilience (%)": 15,
        "Max Kg": 200000
    },
    "precision rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 7500,
        "Lure (%)": 20,
        "Luck (%)": 150,
        "Control": 0,
        "Resilience (%)": 5,
        "Max Kg": 12000
    },
    "wisdom rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 50000,
        "Lure (%)": 10,
        "Luck (%)": 35,
        "Control": 0.05,
        "Resilience (%)": 0,
        "Max Kg": 2000,
        "Ability": "Nhận 70-100% XP thưởng sau khi câu thành công 5 lần liên tiếp"
    },
    "resourceful rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 15000,
        "Lure (%)": 15,
        "Luck (%)": 20,
        "Control": -0.01,
        "Resilience (%)": 0,
        "Max Kg": 1000,
        "Ability": "Nhân đôi hiệu ứng của tất cả loại Mồi, bao gồm cả hiệu ứng tiêu cực"
    },
    "rod of the depths": {
        "Obtained From": "The Depths",
        "Cost (C$)": 750000,
        "Lure (%)": 65,
        "Luck (%)": 130,
        "Control": 0.15,
        "Resilience (%)": 10,
        "Max Kg": 30000,
        "Ability": "Triệu hồi một bóng ma để câu thêm một con cá sau mỗi 3 lần câu thành công"
    },
    "rod of the exalted one": {
        "Obtained From": "Keepers Secret Puzzle",
        "Cost (C$)": 0,
        "Lure (%)": 55,
        "Luck (%)": 170,
        "Control": 0.15,
        "Resilience (%)": 20,
        "Max Kg": 70000,
        "Ability": "Cổ vật Exalted có tỷ lệ câu được cao hơn 2.5 lần"
    },
    "destiny rod": {
        "Obtained From": "The Arch",
        "Cost (C$)": 190000,
        "Lure (%)": -10,
        "Luck (%)": 250,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 10000,
        "Ability": "Tăng 5% tỷ lệ câu được cá Shiny/Sparkling"
    },
    "sunken rod": {
        "Obtained From": "Treasure Chests",
        "Cost (C$)": "N/A",
        "Lure (%)": 30,
        "Luck (%)": 150,
        "Control": 0.15,
        "Resilience (%)": 15,
        "Max Kg": 5000,
        "Ability": "Mỗi 10 lần câu có 25% cơ hội nhận được Treasure Map; 5% cơ hội câu được Sunken Mutation (Giá trị ×4)"
    },
    "auric rod": {
        "Obtained From": "Sunken Chests",
        "Cost (C$)": "N/A",
        "Lure (%)": 20,
        "Luck (%)": 25,
        "Control": 0.05,
        "Resilience (%)": 20,
        "Max Kg": 2500,
        "Ability": "Tất cả cá câu được có giá bán ngẫu nhiên từ ×2 đến ×6"
    },
    "seasons rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 35000,
        "Lure (%)": 20,
        "Luck (%)": 35,
        "Control": 0.03,
        "Resilience (%)": 10,
        "Max Kg": 4000,
        "Ability": "Tăng 20% may mắn khi câu cá trong mùa hiện tại; 20% cơ hội câu được Seasonal Mutation"
    },
    "riptide rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 40000,
        "Lure (%)": 20,
        "Luck (%)": 25,
        "Control": 0.05,
        "Resilience (%)": 5,
        "Max Kg": 3500,
        "Ability": "Thêm thanh thủy triều, mỗi lần ném hoàn hảo tăng 20%. Khi đầy, 3 lần ném tiếp theo được tăng 30% may mắn và 25% lure"
    },
    "abyssal specter rod": {
        "Obtained From": "Atlantis (Ethereal Abyss)",
        "Cost (C$)": 1000000,
        "Lure (%)": 60,
        "Luck (%)": 90,
        "Control": 0.3,
        "Resilience (%)": 70,
        "Max Kg": "∞"
    },
    "zeus rod": {
        "Obtained From": "Atlantis (Zeus Trial)",
        "Cost (C$)": 1700000,
        "Lure (%)": 70,
        "Luck (%)": 70,
        "Control": 0.15,
        "Resilience (%)": 20,
        "Max Kg": "∞",
        "Ability": "Có 10% cơ hội triệu hồi bão làm tăng gấp đôi hiệu ứng lắc, đồng thời đột biến 95% cá với Electric Shock Mutation (Giá trị ×3.5). 5% còn lại bị đột biến thành Charred (Giá trị ×0.5)"
    },
    "tempest rod": {
        "Obtained From": "Atlantis (Sunken Trial)",
        "Cost (C$)": 1850000,
        "Lure (%)": 90,
        "Luck (%)": 120,
        "Control": 0.15,
        "Resilience (%)": 40,
        "Max Kg": 80000,
        "Ability": "+15% tốc độ tiến trình"
    },
    "poseidon rod": {
        "Obtained From": "Atlantis (Poseidon Trial)",
        "Cost (C$)": 1555555,
        "Lure (%)": 50,
        "Luck (%)": 165,
        "Control": 0.2,
        "Resilience (%)": 40,
        "Max Kg": 100000,
        "Ability": "Khi câu được cá, có 25% cơ hội nhận ngay 75% giá trị cơ bản của cá bằng C$; 10% cơ hội triệu hồi Hồn Ma Poseidon, tăng trọng lượng cá lên 75-150% và nhận King's Blessing Mutation (Giá trị ×3.5)"
    },
    "heaven's rod": {
        "Obtained From": "Northern Summit (Crystal Puzzle)",
        "Cost (C$)": 1750000,
        "Lure (%)": 30,
        "Luck (%)": 225,
        "Control": 0.2,
        "Resilience (%)": 30,
        "Max Kg": "∞",
        "Ability": "15% cơ hội câu được Heavenly Mutation (Giá trị ×5)"
    },
    "kraken rod": {
        "Obtained From": "Atlantis (Kraken Pool)",
        "Cost (C$)": 1333333,
        "Lure (%)": 60,
        "Luck (%)": 185,
        "Control": 0.2,
        "Resilience (%)": 15,
        "Max Kg": 115000,
        "Ability": "10% cơ hội nhân đôi cá bắt được; 5% cơ hội áp dụng Tentacle Surge Mutation (Giá trị ×10); Đảm bảo có Legendary, Mythical hoặc Exotic mỗi 50 lần câu"
    },
    "voyager rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 30000,
        "Lure (%)": 25,
        "Luck (%)": 85,
        "Control": 0,
        "Resilience (%)": 10,
        "Max Kg": "∞",
        "Ability": "25% cơ hội câu được Fossilized Mutation (Giá trị ×2.5), bắn laser vào cá bằng pháo quỹ đạo (tăng tốc độ tiến trình)"
    },
    "the lost rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 50000,
        "Lure (%)": 15,
        "Luck (%)": 25,
        "Control": 0.08,
        "Resilience (%)": 8,
        "Max Kg": 55000,
        "Ability": "Sau 6 lần ném hoàn hảo, tăng 150% may mắn trong 3 lần câu tiếp theo"
    },
    "no-life rod": {
        "Obtained From": "Level 500",
        "Cost (C$)": "N/A",
        "Lure (%)": 90,
        "Luck (%)": 105,
        "Control": 0.23,
        "Resilience (%)": 10,
        "Max Kg": "∞",
        "Ability": "Cơ hội làm cá bị choáng trong lúc kéo (thêm tiến trình vào Thanh tiến trình); 20% cơ hội câu được Hexed Mutation (Giá trị ×1.5)"
    },
    "celestial rod": {
        "Obtained From": "Crafting",
        "Cost (C$)": 100000,
        "Lure (%)": 35,
        "Luck (%)": 60,
        "Control": 0.07,
        "Resilience (%)": 5,
        "Max Kg": "∞",
        "Ability": "Sau khi câu được 85 con cá, nhận buff 5 phút: +50 may mắn, +30 lure, +30% XP; tất cả cá trong thời gian buff có Celestial Mutation (Giá trị ×2)"
    },
    "rod of the eternal king": {
        "Obtained From": "Crafting",
        "Cost (C$)": 250000,
        "Lure (%)": 50,
        "Luck (%)": 160,
        "Control": 0.175,
        "Resilience (%)": 15,
        "Max Kg": 75000,
        "Ability": "Mỗi 30 giây, có 10% cơ hội nhận buff +150% may mắn trong 45 giây; nếu bỏ lỡ một lần câu, có 15% cơ hội câu ngay một con cá hiếm hơn; 20% cơ hội câu được Greedy Mutation (Giá trị ×4)"
    },
    "rod of the forgotten fang": {
        "Obtained From": "Crafting",
        "Cost (C$)": 300000,
        "Lure (%)": 78,
        "Luck (%)": 145,
        "Control": 0.22,
        "Resilience (%)": 25,
        "Max Kg": "∞",
        "Ability": "Sau 3 lần ném hoàn hảo, triệu hồi cá mập Meg để mang đến một con cá cấp cao hơn với kích thước tăng 15-20%"
    },
    "seraphic rod": {
        "Obtained From": "Level 1000",
        "Cost (C$)": "N/A",
        "Lure (%)": 95,
        "Luck (%)": 150,
        "Control": 0.25,
        "Resilience (%)": 20,
        "Max Kg": "∞",
        "Ability": "Triệu hồi tia sáng đánh xuống phao câu và ngay lập tức lấp đầy 60% thanh câu cá"
    },
    "haunted rod": {
        "Obtained From": "Witch (FischFright Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 0,
        "Luck (%)": 50,
        "Control": 0.05,
        "Resilience (%)": 0,
        "Max Kg": 1000,
        "Ability": "Có thể câu được FischFright-Exclusive Mutations (Sinister ×1.9 / Ghastly ×2) quanh năm"
    },
    "relic rod": {
        "Obtained From": "Archaeological Site (Archaeological Hunt Event) - Không thể nhận được",
        "Cost (C$)": 8000,
        "Lure (%)": 20,
        "Luck (%)": 25,
        "Control": 0.05,
        "Resilience (%)": 20,
        "Max Kg": 2500,
        "Ability": "-"
    },
    "antler rod": {
        "Obtained From": "Advent Calendar Day 5 (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 25,
        "Luck (%)": 45,
        "Control": 0.02,
        "Resilience (%)": -4,
        "Max Kg": 200,
        "Ability": "25% cơ hội câu được Jolly Mutation (Giá trị ×1.2)"
    },
    "north-star rod": {
        "Obtained From": "Advent Calendar Day 9 (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 5,
        "Luck (%)": 30,
        "Control": 0.04,
        "Resilience (%)": 12,
        "Max Kg": 875,
        "Ability": "-"
    },
    "candy cane rod": {
        "Obtained From": "Winter Village (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": 1500,
        "Lure (%)": 10,
        "Luck (%)": 25,
        "Control": 0.01,
        "Resilience (%)": -2,
        "Max Kg": 150,
        "Ability": "10% cơ hội câu được Festive Mutation (Giá trị ×1.4)"
    },
    "krampus's rod": {
        "Obtained From": "Crafting (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": 30000,
        "Lure (%)": 30,
        "Luck (%)": 15,
        "Control": 0.15,
        "Resilience (%)": 8,
        "Max Kg": "∞",
        "Ability": "Mỗi 10 lần câu, nhận buff ngẫu nhiên trong 4 phút (Lure V +50% Lure hoặc Luck V +25% Luck)"
    },
    "frost warden rod": {
        "Obtained From": "Winter Bundle (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 10,
        "Luck (%)": 45,
        "Control": 0.05,
        "Resilience (%)": 15,
        "Max Kg": 2200,
        "Ability": "-"
    },
    "fischmas rod": {
        "Obtained From": "XMAS Pack (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 10,
        "Luck (%)": 45,
        "Control": 0.05,
        "Resilience (%)": 15,
        "Max Kg": 2200,
        "Ability": "-"
    },
    "frostfire rod": {
        "Obtained From": "XMAS Pack 2 (Fischmas Event) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 20,
        "Luck (%)": 35,
        "Control": 0.08,
        "Resilience (%)": 12,
        "Max Kg": 2200,
        "Ability": "-"
    },
    "firework rod": {
        "Obtained From": "Golden Tide Quest - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 35,
        "Luck (%)": 45,
        "Control": 0.15,
        "Resilience (%)": 15,
        "Max Kg": 25000,
        "Ability": "15% cơ hội câu được Firework Mutation (Giá trị ×3.5); Giảm 20% tốc độ tiến trình cá voi; +0.2% tỷ lệ gặp cá voi"
    },
    "buddy bond rod": {
        "Obtained From": "Bob - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 0,
        "Luck (%)": 5,
        "Control": 0,
        "Resilience (%)": 0,
        "Max Kg": 300,
        "Ability": "Tăng 30% tất cả chỉ số khi chơi cùng bạn bè"
    },
    "astral rod": {
        "Obtained From": "Code: ThankYouFollowers2 - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 10,
        "Luck (%)": 30,
        "Control": 0.05,
        "Resilience (%)": 5,
        "Max Kg": 1000,
        "Ability": "5% cơ hội câu được Lunar Mutation (Giá trị ×2.5)"
    },
    "event horizon rod": {
        "Obtained From": "Code: ThankYouFollowers3 - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 10,
        "Luck (%)": 30,
        "Control": 0.05,
        "Resilience (%)": 5,
        "Max Kg": 1000,
        "Ability": "5% cơ hội câu được Lunar Mutation (Giá trị ×2.5) (Không hoạt động)"
    },
    "sovereign doombringer": {
        "Obtained From": "Awarded to Official Content Creators (Northern Expedition Update) - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 65,
        "Luck (%)": 150,
        "Control": 0.15,
        "Resilience (%)": 10,
        "Max Kg": "∞",
        "Ability": "Mỗi lần ném, một chiếc búa sẽ xuất hiện và lấp đầy khoảng 25% thanh tiến trình"
    },
    "clickbait caster": {
        "Obtained From": "Given to Official Content Creators - Không thể nhận được",
        "Cost (C$)": "N/A",
        "Lure (%)": 50,
        "Luck (%)": 225,
        "Control": 0.25,
        "Resilience (%)": 30,
        "Max Kg": "∞",
        "Ability": "Triệu hồi một bóng ma bắt một con cá thêm mỗi 3 lần câu thành công"
    },
    "Volcanic Rod": {
        "Obtained From": "Volcanic Vents - khu 1",
        "Cost (C$)": 300000,
        "Lure (%)": 30,
        "Luck (%)": 90,
        "Control": 0.1,
        "Resilience (%)": 15,
        "Max Kg": "∞",
        "Ability": "20% cơ hội bắt Ashen Fortune đột biếnbiến (Giá trị ×5)"
    },
    "Challenger's Rod": {
        "Obtained From": "Mariana's Veil (Challenger's Deep) - khu 2",
        "Cost (C$)": 2500000,
        "Lure (%)": 90,
        "Luck (%)": 110,
        "Control": 0.2,
        "Resilience (%)": 40,
        "Max Kg": "∞",
        "Ability": "+20 progress speed"
    },
    "Rod Of The Zenith": {
        "Obtained From": "Mariana's Veil (Abyssal Zenith) - khu 3",
        "Cost (C$)": 10000000,
        "Lure (%)": 85,
        "Luck (%)": 145,
        "Control": 0.15,
        "Resilience (%)": 15,
        "Max Kg": "∞",
        "Ability": "Tất cả lần câu cá đều có minigame phụ. Giữ cá trong thanh câu sẽ tăng cơ hội đột biến (từ 0.1x trở lên) và giảm resilience từ 100"
    },
    "Ethereal Prism Rod": {
        "Obtained From": "Mariana's Veil (Calm Zone) - khu 4",
        "Cost (C$)": 15000000,
        "Lure (%)": 95,
        "Luck (%)": 195,
        "Control": 0.25,
        "Resilience (%)": 40,
        "Max Kg": "∞",
        "Ability": "50% bắt cá với đột biến Prismize (giá trị x8)"
    },
    "Leviathan's Fang Rod": {
        "Obtained From": "Veil of the Forsaken - khu câu thứ 5",
        "Cost (C$)": 1000000,
        "Lure (%)": 70,
        "Luck (%)": 180,
        "Control": 0.1,
        "Resilience (%)": 5,
        "Max Kg": "∞",
        "Ability": "Cung cấp +50 độ bền, +20% tốc độ tiến trình và thêm kỹ năng Chém khi câu Scylla."
    }
}