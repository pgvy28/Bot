{
    "baits": [
      {
        "name": "Bagel",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 25,
          "univ_luck": 0,
          "resilience": 15,
          "lure": 0,
          "favoring_fish": 9
        }
      },
      {
        "name": "Worm",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 25,
          "univ_luck": 0,
          "resilience": 0,
          "lure": 15,
          "favoring_fish": 31
        }
      },
      {
        "name": "Insect",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 35,
          "univ_luck": 0,
          "resilience": 0,
          "lure": 5,
          "favoring_fish": 25
        }
      },
      {
        "name": "Flakes",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 55,
          "univ_luck": 0,
          "resilience": -3,
          "lure": 10,
          "favoring_fish": 21
        }
      },
      {
        "name": "Garbage",
        "sources": {
          "common_crate": false,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": 0,
          "univ_luck": -250,
          "resilience": 50,
          "lure": -5,
          "favoring_fish": 0
        }
      },
      {
        "name": "Shrimp",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 45,
          "univ_luck": 25,
          "resilience": -5,
          "lure": 0,
          "favoring_fish": 22
        }
      },
      {
        "name": "Maggot",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 0,
          "univ_luck": 35,
          "resilience": 0,
          "lure": -10,
          "favoring_fish": 1
        }
      },
      {
        "name": "Magnet",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 200,
          "univ_luck": 0,
          "resilience": 0,
          "lure": 0,
          "favoring_fish": 24
        }
      },
      {
        "name": "Minnow",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": false,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 65,
          "univ_luck": 0,
          "resilience": -10,
          "lure": 0,
          "favoring_fish": 24
        }
      },
      {
        "name": "Seaweed",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 35,
          "univ_luck": 0,
          "resilience": 10,
          "lure": 20,
          "favoring_fish": 24
        }
      },
      {
        "name": "Coral",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": 0,
          "univ_luck": 0,
          "resilience": 20,
          "lure": 20,
          "favoring_fish": 5
        }
      },
      {
        "name": "Squid",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "25+",
          "pref_luck": 55,
          "univ_luck": 45,
          "resilience": 0,
          "lure": -25,
          "favoring_fish": 18
        }
      },
      {
        "name": "Rapid Catcher",
        "sources": {
          "common_crate": true,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 0,
          "univ_luck": 0,
          "resilience": -15,
          "lure": 35,
          "favoring_fish": 0
        }
      },
      {
        "name": "Super Flakes",
        "sources": {
          "common_crate": false,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 0,
          "univ_luck": 70,
          "resilience": -15,
          "lure": 0,
          "favoring_fish": 3
        }
      },
      {
        "name": "Coal",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": true,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "50+",
          "pref_luck": 45,
          "univ_luck": 0,
          "resilience": -10,
          "lure": 0,
          "favoring_fish": 7
        }
      },
      {
        "name": "Fish Head",
        "sources": {
          "common_crate": false,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "5+",
          "pref_luck": 150,
          "univ_luck": 0,
          "resilience": -10,
          "lure": 10,
          "favoring_fish": 49
        }
      },
      {
        "name": "Night Shrimp",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": true,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "25+",
          "pref_luck": 0,
          "univ_luck": 90,
          "resilience": 0,
          "lure": 15,
          "favoring_fish": 4
        }
      },
      {
        "name": "Weird Algae",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": true,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "25+",
          "pref_luck": 0,
          "univ_luck": 200,
          "resilience": 0,
          "lure": -35,
          "favoring_fish": 4
        }
      },
      {
        "name": "Deep Coral",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": -10,
          "univ_luck": 0,
          "resilience": 50,
          "lure": 0,
          "favoring_fish": 13
        }
      },
      {
        "name": "Truffle Worm",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "50+",
          "pref_luck": 300,
          "univ_luck": 0,
          "resilience": 0,
          "lure": -10,
          "favoring_fish": 29
        }
      },
      {
        "name": "Kraken Tentacle",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": 100,
          "univ_luck": 35,
          "resilience": 15,
          "lure": 35,
          "favoring_fish": 0
        }
      },
      {
        "name": "Instant Catcher",
        "sources": {
          "common_crate": false,
          "bait_crate": true,
          "quality_crate": true,
          "volc_geode": true,
          "coral_geode": true
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": 0,
          "univ_luck": -20,
          "resilience": -15,
          "lure": 65,
          "favoring_fish": 0
        }
      },
      {
        "name": "Shark Head",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": true,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "25+",
          "pref_luck": 225,
          "univ_luck": 30,
          "resilience": 10,
          "lure": -5,
          "favoring_fish": 6
        }
      },
      {
        "name": "Hangman's Hook",
        "sources": {
          "common_crate": false,
          "bait_crate": false,
          "quality_crate": false,
          "volc_geode": false,
          "coral_geode": false
        },
        "stats": {
          "angler_quests": "N/A",
          "pref_luck": 150,
          "univ_luck": 35,
          "resilience": 20,
          "lure": -5,
          "favoring_fish": 0
        }
      }
    ]
  }