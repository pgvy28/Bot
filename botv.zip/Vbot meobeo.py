import discord
from discord.ext import commands
import json
import asyncio

# Khởi tạo bot với tiền tố lệnh (prefix)
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
bot = commands.Bot(command_prefix="v.", intents=intents)


with open('Rods.js', 'r', encoding='utf-8') as f:
    rods_data = json.load(f)

normalized_rods_data = {}
for rod_name, rod_info in rods_data.items():
    normalized_name = rod_name.lower().replace(" ", "").replace("rod", "").replace("-", "")
    normalized_rods_data[normalized_name] = rod_info

with open('mutation.txt', 'r', encoding='utf-8') as f:
    mutation_data = json.load(f)

with open('enchant.txt', 'r', encoding='utf-8') as f:
    enchant_data = []
    for line in f:
        if "Enchant" not in line:
            parts = line.split("(", 1)
            if len(parts) == 2:
                name, attributes = parts
                attributes = attributes.replace("(", "").replace(")", "").strip()
                attributes = ", ".join([f"**{attr.strip()}**" for attr in attributes.split(",")])
                enchant_data.append(f"{name.strip()} ({attributes})")

with open('baits.js', 'r', encoding='utf-8') as f:
    baits_data = json.load(f)["baits"]

normalized_baits_data = {}
for bait in baits_data:
    normalized_name = bait["name"].lower().replace(" ", "")
    normalized_baits_data[normalized_name] = bait

def get_pages(data, items_per_page=10):
    pages = []
    for i in range(0, len(data), items_per_page):
        pages.append(data[i:i + items_per_page])
    return pages

mutation_pages = get_pages(mutation_data, items_per_page=10)
enchant_pages = get_pages(enchant_data, items_per_page=10)

def xp_can_de(lenh_level):
    return 190 * lenh_level

def xp_tong(level):
    return 190 * (level - 1) * level // 2

def level_tu_xp(exp):
    level = 1
    while xp_tong(level + 1) <= exp:
        level += 1
    return level

@bot.event
async def on_ready():
    print(f"Logged in: {bot.user} my sigma bot")

@bot.event
async def on_message(message):
    print(f"Received message: {message.content} from {message.author} in channel {message.channel.id}")  # Thêm logging
    if message.author.bot:
        return
    
    if message.channel.id == CHANNEL_ID or (message.channel.id == NEW_CHANNEL_ID and message.author.id == AUTHORIZED_USER_ID):
        if message.content.lower() == "v.":
            await message.channel.send("GÌ? 🤨, không biết `v.help` à nhóc?")
        
        elif message.content.lower() in ["v.help", "v. help", "v.?", "v. ?"]:
            with open('dsbot.txt', 'r', encoding='utf-8') as f:
                ds_content = f.read()
            await message.channel.send(ds_content)
        
        elif message.content.lower() == "v.expfarm":
            with open('expfarm.txt', 'r', encoding='utf-8') as f:
                expfarm_content = f.read()
            await message.channel.send(expfarm_content)
        
        elif message.content.lower() == "v.cfarm":
            with open('cfarm.txt', 'r', encoding='utf-8') as f:
                cfarm_content = f.read()
            await message.channel.send(cfarm_content)
        
        elif message.content.lower().startswith("v.info"):
            rod_name = message.content.lower().replace("v.info", "").replace(" ", "").replace("rod", "").replace("-", "").strip()
            rod_info = None
            for key in normalized_rods_data.keys():
                if rod_name in key:
                    rod_info = normalized_rods_data[key]
                    break
            if rod_info:
                rod_info_message = f"Thông tin cần câu `{rod_name}`:\n"
                for key, value in rod_info.items():
                    rod_info_message += f"- **{key}**: {value}\n"
                await message.channel.send(rod_info_message)
            else:
                await message.channel.send(f"Không tìm thấy thông tin về cần câu `{rod_name}`.")
        
        elif message.content.lower().startswith("v.dotbien") or message.content.lower().startswith("v.mutation"):
            try:
                parts = message.content.lower().split()
                if len(parts) == 2:
                    page = int(parts[1]) - 1
                    if page < 0 or page >= len(mutation_pages):
                        await message.channel.send("Số trang không hợp lệ. Vui lòng nhập số trang từ 1 đến 5.")
                        return
                    else:
                        embed = discord.Embed(title=f"Danh sách đột biến - Trang {page + 1}", description="", color=0x00ff00)
                        for item in mutation_pages[page]:
                            appraisable_icon = "<:v_:1342343158838853749>" if item['appraisable'] else "<:x_:1342343165029384283>"
                            embed.add_field(name=item["name"], value=f"Gấp: {item['multiplier']}, Thẩm định: {appraisable_icon}", inline=False)
                        embed.set_footer(text=f"Page {page + 1}/{len(mutation_pages)}")
                        await message.channel.send(embed=embed)
                else:
                    await message.channel.send("Nhập số trang cần xem sau lệnh `v.mutation <số trang>` hoặc `v.dotbien <số trang>`.")
            except ValueError:
                await message.channel.send("Nhập số trang cần xem sau lệnh `v.mutation <số trang>` hoặc `v.dotbien <số trang>`.")
        
        elif message.content.lower().startswith("v.enchant"):
            try:
                parts = message.content.lower().split()
                if len(parts) == 2:
                    page = int(parts[1]) - 1
                    if page < 0 or page >= len(enchant_pages):
                        await message.channel.send("Số trang không hợp lệ. Vui lòng nhập số trang từ 1 đến 5.")
                        return
                    else:
                        embed = discord.Embed(title=f"Danh sách enchant - Trang {page + 1}", description="", color=0x00ff00)
                        for item in enchant_pages[page]:
                            embed.add_field(name="Enchant", value=item.strip(), inline=False)
                        embed.set_footer(text=f"Page {page + 1}/{len(enchant_pages)}")
                        await message.channel.send(embed=embed)
                else:
                    await message.channel.send("Nhập số trang cần xem sau lệnh `v.enchant <số trang>`.")
            except ValueError:
                await message.channel.send("Nhập số trang cần xem sau lệnh `v.enchant <số trang>`.")
        
        elif message.content.lower().startswith("v.level"):
            try:
                parts = message.content.lower().split()
                if len(parts) == 2:
                    level = int(parts[1])
                    if level < 0:
                        await message.channel.send("Số cần nhập phải lớn hơn 0, m âm level à:)?")
                        return
                    else:
                        total_xp = xp_tong(level)
                        await message.channel.send(f"Level `{level}` cần tổng cộng `{total_xp}` XP.")
                elif len(parts) == 3:
                    current_level = int(parts[1])
                    target_level = int(parts[2])
                    if current_level < 0 or target_level <= current_level:
                        await message.channel.send("Level hiện tại phải lớn hơn 0 và level chỉ định phải lớn hơn level hiện tại ok?")
                        return
                    else:
                        xp_needed = xp_tong(target_level) - xp_tong(current_level)
                        await message.channel.send(f"Bạn level `{current_level}` cần `{xp_needed}` XP để lên level `{target_level}` (tổng XP: {xp_tong(target_level)}).")
                else:
                    await message.channel.send("Nhập level cần tính sau lệnh `v.level <level>` hoặc `v.level <current_level> <target_level>`.")
            except ValueError:
                await message.channel.send("Nhập level cần tính sau lệnh `v.level <level>` hoặc `v.level <current_level> <target_level>`.")
        
        elif message.content.lower().startswith("v.xp") or message.content.lower().startswith("v.exp"):
            try:
                parts = message.content.lower().split()
                if len(parts) == 2:
                    xp = int(parts[1])
                    if xp < 0:
                        await message.channel.send("Số XP cần nhập phải lớn hơn 0.")
                        return
                    else:
                        level = level_tu_xp(xp)
                        await message.channel.send(
                            f"XP `{xp}` tương ứng với level `{level}`\n"
                            f"X2 `gamepass`: {xp * 2} XP, level {level_tu_xp(xp * 2)}\n"
                            f"X2.25 `clever enchant`: {xp * 2.25} XP, level {level_tu_xp(xp * 2.25)}\n"
                            f"X3.25 `perfect/gamepass`: {xp * 3.25} XP, level {level_tu_xp(xp * 3.25)}\n"
                            f"X4.25 `clever/gamepass/perfect`: {xp * 4.25} XP, level {level_tu_xp(xp * 4.25)}"
                        )
                else:
                    await message.channel.send("Nhập XP cần tính sau lệnh `v.xp <xp>` hoặc `v.exp <xp>`.")
            except ValueError:
                await message.channel.send("Nhập XP cần tính sau lệnh `v.xp <xp>` hoặc `v.exp <xp>`.")
        
        elif message.content.lower().startswith("v.bait"):
            try:
                parts = message.content.lower().split()
                if len(parts) == 2:
                    bait_name = parts[1].replace(" ", "").strip()
                    matching_baits = [bait for key, bait in normalized_baits_data.items() if bait_name in key]
                    if len(matching_baits) == 1:
                        bait_info = matching_baits[0]
                        sources = bait_info["sources"]
                        stats = bait_info["stats"]
                        sources_message = "\n".join([f"- **{key}**: {'<:v_:1342343158838853749>' if value else '<:x_:1342343165029384283>'}" for key, value in sources.items()])
                        stats_message = "\n".join([f"- **{key}**: {value}" for key, value in stats.items()])
                        bait_info_message = f"Thông tin bait `{bait_info['name']}`:\n\n**Sources**:\n{sources_message}\n\n**Stats**:\n{stats_message}"
                        await message.channel.send(bait_info_message)
                    elif len(matching_baits) > 1:
                        await message.channel.send(f"Có nhiều bait có tên bắt đầu với `{bait_name}`. Vui lòng nhập tên đầy đủ.")
                    else:
                        await message.channel.send(f"Không tìm thấy thông tin về bait `{bait_name}`.")
                else:
                    await message.channel.send("Nhập tên bait cần xem sau lệnh `v.bait <tên bait>`.")
            except ValueError:
                await message.channel.send("Nhập tên bait cần xem sau lệnh `v.bait <tên bait>`.")

bot.run(TOKEN)